// truck-model.js — загрузка модели тягача для PackOnTruck
// Использование:
//   import { loadTruck } from './truck-model.js';
//   const truck = await loadTruck('assets/European_lorry_truck.stl', { length: 6.5 });
//   scene.add(truck);
//
// Требуется three и STLLoader (three/examples/jsm/loaders/STLLoader.js).

import * as THREE from 'three';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';

/**
 * Загружает STL тягача, масштабирует до заданной длины (в метрах),
 * центрирует по X/Z и ставит колёсами на y = 0.
 * @param {string} url - путь к .stl
 * @param {{ length?: number, material?: THREE.Material }} opts
 * @returns {Promise<THREE.Group>}
 */
export function loadTruck(url, opts = {}) {
  const length = opts.length ?? 6.5;
  const material = opts.material ?? new THREE.MeshStandardMaterial({
    color: 0xf7f7f7, roughness: 0.5, metalness: 0.05, flatShading: true,
  });

  return new Promise((resolve, reject) => {
    new STLLoader().load(url, (geometry) => {
      geometry.computeBoundingBox();
      const bb = geometry.boundingBox;
      const size = new THREE.Vector3();
      bb.getSize(size);
      const scale = length / size.x; // X — вдоль машины

      const mesh = new THREE.Mesh(geometry, material);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.scale.setScalar(scale);

      const center = new THREE.Vector3();
      bb.getCenter(center);
      mesh.position.set(-center.x * scale, -bb.min.y * scale, -center.z * scale);

      const group = new THREE.Group();
      group.name = 'truck';
      group.add(mesh);
      // Габариты в метрах — пригодится для расстановки груза
      group.userData.dimensions = {
        length,
        width: size.z * scale,
        height: size.y * scale,
      };
      resolve(group);
    }, undefined, reject);
  });
}
